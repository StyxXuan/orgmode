package com.example.org_mode.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DateUtils {
    public static Date getNextDate(Date today){
        if(today == null)
            return null;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(today);
        calendar.add(Calendar.DAY_OF_MONTH, 1);

        return calendar.getTime();
    }

    public static Date getLastDate(Date today){
        if(today == null)
            return null;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(today);
        calendar.add(Calendar.DAY_OF_MONTH, -1);

        return calendar.getTime();
    }

    public static List<Date> getWeek() {
        Calendar calendar = Calendar.getInstance();
        // 获取本周的第一天
        int firstDayOfWeek = calendar.getFirstDayOfWeek();
        List<Date> list = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            calendar.set(Calendar.DAY_OF_WEEK, firstDayOfWeek + i);
            list.add(calendar.getTime());
        }

        return list;
    }

    public static List<Date> getWeek(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int firstDayOfWeek = calendar.getFirstDayOfWeek();
        List<Date> list = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            calendar.set(Calendar.DAY_OF_WEEK, firstDayOfWeek + i);
            list.add(calendar.getTime());
        }

        return list;
    }

    public static List<Date> getLastWeek(List<Date> thisWeek){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(thisWeek.get(0));
        calendar.add(Calendar.DAY_OF_MONTH, -7);
        return getWeek(calendar.getTime());
    }

    public static List<Date> getNextWeek(List<Date> thisWeek){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(thisWeek.get(0));
        calendar.add(Calendar.DAY_OF_MONTH, 7);
        return getWeek(calendar.getTime());
    }

    public static List<ScheduleDate> convertDate(List<Date> dates){
        List<ScheduleDate> converted = new ArrayList<ScheduleDate>();
        for(int i=0; i<dates.size(); i++){
            converted.add(convertDate(dates.get(i)));
        }

        return converted;
    }

    public static ScheduleDate convertDate(Date date) {
        return new ScheduleDate(new SimpleDateFormat("yyyy-MM-dd E").format(date));
    }

    public static String MonthNum2String(String month){
        int m = Integer.parseInt(month);
        switch (m){
            case 1:
                return "Jan";

            case 2:
                return "Feb";

            case 3:
                return "Mar";

            case 4:
                return "Apr";

            case 5:
                return "May";

            case 6:
                return "June";

            case 7:
                return "July";

            case 8:
                return "Aug";

            case 9:
                return "Sept";

            case 10:
                return "Oct";

            case 11:
                return "Nov";

            case 12:
                return "Dec";

            default:
                return "";
        }
    }
}
