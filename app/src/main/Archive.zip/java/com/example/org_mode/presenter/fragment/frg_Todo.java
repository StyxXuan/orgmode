package com.example.org_mode.presenter.fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.example.org_mode.R;

/**
 * Created by dm on 16-3-29.
 * 第一个页面
 */
public class frg_Todo extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frg_todo, container, false);
        return view;
    }
}
