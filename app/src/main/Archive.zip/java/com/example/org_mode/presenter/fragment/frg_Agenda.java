package com.example.org_mode.presenter.fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.OrientationHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.example.org_mode.R;
import com.example.org_mode.presenter.Adapter.DayAdapter;
import com.example.org_mode.presenter.Adapter.ScheduleAdapter;
import com.example.org_mode.utils.DateUtils;
import com.example.org_mode.utils.ScheduleDate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.SimpleFormatter;

import static com.example.org_mode.model.FileResolution.getItembyDate;
import static com.example.org_mode.utils.DateUtils.convertDate;
import static com.example.org_mode.utils.DateUtils.getLastWeek;
import static com.example.org_mode.utils.DateUtils.getNextWeek;
import static com.example.org_mode.utils.DateUtils.getWeek;

/**
 * Created by dm on 16-3-29.
 * 第一个页面
 */
public class frg_Agenda extends Fragment {
    List<Date> dates;
    @SuppressLint("WrongConstant")
    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frg_agenda, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerview);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        DayAdapter recycleAdapter = new DayAdapter(getContext());
        getDates();

        recycleAdapter.setData(convertDate(dates));

        recyclerView.setLayoutManager(layoutManager);
        layoutManager.setOrientation(OrientationHelper.VERTICAL);
        recyclerView.setAdapter(recycleAdapter);
        recyclerView.setItemAnimator( new DefaultItemAnimator());
        return view;
    }

    void getDates(){
        dates = getWeek();
    }

    void nextWeek(){
        dates = getNextWeek(dates);
    }

    void lastWeek(){
        dates = getLastWeek(dates);
    }
}